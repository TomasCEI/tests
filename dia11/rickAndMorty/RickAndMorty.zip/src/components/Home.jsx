const Home = () => {
   return <h1>Soy Home</h1>;
};
export default Home;
