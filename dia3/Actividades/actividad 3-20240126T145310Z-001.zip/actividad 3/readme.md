Dado el siguiente código realizar:
Comentar cada una de las líneas JS, las tags <section> del html, y la hoja de estilos CSS
Agregar un botón general de "Guardar Color" para que cada vez que lo presione, se almacene en un array el color seleccionado.
Agregar una lista que vaya mostrando cada uno de los colores guardados mostrando su código RGB y un circulo relleno con ese color. 
Agregar un EventListener de Click a cada item de la lista para que los sliders y cuadros se carguen con el color seleccionado.
Agregar un botón general de "Borrar Lista" para quitar todos los colores guardados
Permitir almacenar un máximo de 10 colores borrando los colores mas viejos
Agregar un botón de "Borrar" a cada item de la lista para eliminar dicho item del array.